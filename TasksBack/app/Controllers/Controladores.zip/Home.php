<?php

namespace App\Controllers;

use App\Models\participantes;
use App\Models\codigoPostal;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'public/PHPMailer/Exception.php';
require 'public/PHPMailer/PHPMailer.php';
require 'public/PHPMailer/SMTP.php';
define('METHOD', 'AES-256-CBC');
define('SECRET_KEY', 'op5813Sa2135So56N');
define('SECRET_IV', '7884588');

class Home extends BaseController
{
    //Regresa la vista
    public function index(): string
    {
        return view('index');
    }

    //Página de términos y condiciones
    public function terms()
    {
        return view('terminosycondiciones/terminos');
    }

    //Página de Aviso de Privacidad
    public function privacidad()
    {
        return view('avisodeprivacidad/privacidad');
    }

    //Ingresa nuevo participante
    public function agregarParticipante()
    {
        $participante = new participantes();
        $nombre = $this->request->getVar('nombre');
        $apellidos = $this->request->getVar('apellidos');
        $correo = $this->request->getVar('correo');
        $telefono = $this->request->getVar('telefono');
        $sexo = $this->request->getVar('sexo');
        $calle = $this->request->getVar('calle');
        $colonia = $this->request->getVar('colonia');
        $codigopostal = $this->request->getVar('codigopostal');
        $noExt = $this->request->getVar('noExt');

        $data = [
            'nombre' => trim($nombre),
            'apellidos' => trim($apellidos),
            'sexo' => $sexo,
            'correo' => trim($correo),
            'telefono' => $telefono,
            'gymid' => 3,
            'status' => 'Pre-Registro',
            'FechaContrato' => date('Y-m-d H:i:s'),
            'NoExt' => $noExt,
            'Calle' => $calle,
            'Colonia' => $colonia,
            'CP' => $codigopostal,
            'Municipio' => 'TAPACHULA',
            'Estado' => 'Chiapas',
        ];
        $resp = $participante->agregarParticipante($data);
        echo $resp;
    }

    // ELIMINAR PARTICIPANTE AL RECHAZAR PAGO
    public function eliminarParticipante()
    {
        $participante = new participantes();
        $id = $this->request->getVar('id');
        $data = ["Id" => $id];
        $respuesta = $participante->eliminarParticipante($data);
        echo $respuesta;
    }

    //consulta el codigo postal del participante
    public function cp()
    {
        $infoColonias = new codigoPostal();
        $cp = $this->request->getVar('cp');
        $colonias = $infoColonias->colonias($cp);
        return json_encode($colonias);
    }

    // agrega en la tabla socioEvento y PagoPuntoVenta
    public function PagoEvento()
    {
        $participante = new participantes();

        $Descripcion = $this->request->getVar('Descripcion');
        $total = $this->request->getVar('Total');
        $Nombre = $this->request->getVar('Nombre');
        $TipoPago = $this->request->getVar('TipoPago');
        $Email = $this->request->getVar('Email');
        $IdCliente = $this->request->getVar('IdCliente');
        $IdPago = $this->request->getVar('IdPago');
        $status = $this->request->getVar('Status');
        $idOrden = $this->request->getVar('idOrden');
        $paypalLink = $this->request->getVar('paypalLink');
        $user = $this->request->getVar('UserAgent');
        $ip = $this->request->getVar('IP');

        $socioEvento = [
            'IdSocio' => $IdCliente,
            'IdEvento' => 1
        ];

        $pagoPuntaVenta = [
            'Descripcion' => $Descripcion,
            'Total' => $total,
            'Nombre' => $Nombre,
            'TipoPago' => $TipoPago,
            'IdPago' => $IdPago,
            'Email' => $Email,
            'Fecha' => date('Y-m-d h:m:s'),
            'IdCliente' => $IdCliente,
            'IdEvento' => 1,
            'Status' => $status,
            'IdOrden' => $idOrden,
            'paypalLink' => $paypalLink,
            'UserAgent' => $user,
            'IP' => $_SERVER['REMOTE_ADDR'],
        ];

        $consulta = $participante->PagoEvento($socioEvento, $pagoPuntaVenta);
        return json_encode($consulta);
    }

    // trae la informacion del socio
    public function socioInformacion()
    {
        $participante = new participantes();
        $id = $this->request->getVar('id');
        $consulta = $participante->socioInformacion($id);
        return json_encode($consulta);
    }

    // Crear QR
    public function crearQR()
    {
        $img = $_POST['imgBase64'];
        $idSocio = $_POST['id'];
        $nombre = $_POST['nombre'];
        $apellidos = $_POST['apellidos'];
        $img = str_replace('data:image/png;base64,', '', $img);
        $img = str_replace(' ', '+', $img);
        $data = base64_decode($img);
        $directory = './public/uploads/Socio/' . $idSocio;
        if (is_dir($directory)) {
            return json_encode(10);
        } else {
            mkdir($directory, 0777, true);
            $file = $directory . '/' . $idSocio . '.png';
            $success = file_put_contents($file, $data);
            return $success ? '1' : '0';
        }
    }

    // FUNCION QUE OBTIENE ID ENCRIPTDADA
    public function idEncriptado()
    {
        $participante = new participantes();
        $id = $this->request->getVar('id');
        $consulta = $participante->idEncriptado($id);
        $claveSecreta = "TwoThousan223@sadfdgtre";
        if ($consulta != 0) {
            $idEncriptado = $this->encrypt($consulta, $claveSecreta);
            $response = array(
                'OriginalId' => $consulta,
                'EncryptedId' => $idEncriptado
            );
            return json_encode($response);
        } else {
            return json_encode(0);
        }
    }

    // PRUEBAS
    public function ip()
    {
        // $variable = $_SERVER['HTTP_CLIENT_IP'];
        // print_r($variable);
        if (!empty($_SERVER['HTTP_CLIENT_IP']))
            return $_SERVER['HTTP_CLIENT_IP'];
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        return $_SERVER['REMOTE_ADDR'];
    }





    public function mandarCorreo()
    {
        $participante = new participantes();
        $keyFood = $this->request->getVar('llavenoencrip');
        $keyencrip = $this->request->getVar('llave');
        $nuevoCorreo = $participante->informacioPago($keyFood);
        $mail = new PHPMailer(true);
        try {
            $mail->SMTPDebug = 0;
            $mail->isSMTP();
            $mail->Host       = 'smtp.hostinger.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'noreply@amifit.mx';
            $mail->Password   = 'n0R3ply$';
            $mail->SMTPSecure = "tls";
            $mail->SMTPAutoTLS = false;
            $mail->Port = 587;
            $mail->setFrom('noreply@amifit.mx', 'Carrera Hortensias Correo');
            $mail->AddAddress($nuevoCorreo[0]->Email); ///Aqui irá el Correo del Administrador Principal
            $mail->isHTML(true);
            $mail->AddEmbeddedImage($_SERVER['DOCUMENT_ROOT'] . '/public_html_CarreraDeLasHortensiasBueno/public/img/purple_minimum.png', 'purple_minimum', 'purple_minimum.png');
            $mail->AddEmbeddedImage($_SERVER['DOCUMENT_ROOT'] . '/public_html_CarreraDeLasHortensiasBueno/public/uploads/Socio/' . $keyFood . '/' . $keyFood . '.png', $keyencrip, $keyencrip . '.png');
            $mail->Subject =  mb_convert_encoding('Carrera Hortensias', 'ISO-8859-1', 'UTF-8');
            $mail->Body =
                '<div align="center" style="font-family: Roboto-regular, Helvetica; color:#A3B4BB">
                <div>
                    <img src="cid:purple_minimum" width="300px">
                </div>
                <div style="margin-top: 8px; color:#8B8B8B; font-size: 24px;">
                    <!-- Aquí debería estar tu mensaje emotivo --> 
                ¡Logro asombroso! Has cruzado la línea de partida y ahora estás oficialmente en la carrera. 
                🏁 Muestra este código QR para acceder a la competición. ¡Buena suerte en tu recorrido hacia la victoria! 🚀
                    </div>
                <div style="margin-top: 8px; color:#8B8B8B; font-size: 24px;">
                    <!-- Aquí debería estar tu mensaje emotivo --> 
                ' . 'Id pago:' . ($nuevoCorreo[0]->TipoPago == 'PayPal' ? $nuevoCorreo[0]->idOrden : $nuevoCorreo[0]->IdPago) . '
                <br>
                ' . 'Nombre:' . $nuevoCorreo[0]->Nombre . '
                <br>
                ' . 'Total $' . $nuevoCorreo[0]->Total . '
                    </div>
                <hr style="color:#D5D8DC; border-top: 2px; width: 27%;">
                <div style="margin-top: 8px; color:#2874A6; font-size: 20px;"> 
                </div>
                <div>
                    <img src="cid:' . $keyencrip . '" width="300px">
                </div>
            </div>
            ';
            $mail->send();
            return 1;
        } catch (Exception $e) {
            return "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }

    public function encrypt($data, $key)
    {
        $iv = openssl_random_pseudo_bytes(16); // Genera un IV de 16 bytes
        $encryptedData = openssl_encrypt($data, 'aes-256-cbc', $key, 0, $iv);
        return base64_encode($iv . $encryptedData);
    }

    public function consultarLlave()
    {
        $participante = new participantes();
        $llave = $this->request->getVar('llave');
        $resultado = $participante->buscarLlave($llave);
        $claveSecreta = "TwoThousan223@sadfdgtre";
        if ($resultado == '1') {
            $id['Id'] = $participante->buscarIdUsuario($llave);
            $idEncriptado = $this->encrypt($id['Id'], $claveSecreta);
            $response = array(
                'OriginalId' => $id['Id'],
                'EncryptedId' => $idEncriptado
            );
            // Convertir el array a formato JSON
            return json_encode($response);
        } else {
            return  '0';
        }
    }





}
