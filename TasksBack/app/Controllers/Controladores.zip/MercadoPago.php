<?php

namespace App\Controllers;

use MercadoPago\SDK;
use MercadoPago\Preference;
use MercadoPago\Item;
use MercadoPago\Payment;

// ACCESS TOKEN MERCADO PAGO
SDK::setAccessToken(env('ACCESS_TOKEN'));

class mercadoPago extends BaseController
{
    //Regresa la vista
    public function Pago()
    {
        $monto = $this->request->getVar('monto');
        $descripcion = $this->request->getVar('descripcion');
        $correo = $this->request->getVar('correo');
        $preference = new Preference();

        $item = new Item();
        $item->id = '001';
        $item->title = $descripcion;
        $item->quantity = 1;
        $item->unit_price = $monto;
        $item->currency_id = 'MXN';

        $preference->items = array($item);

        $id = $this->request->getVar('id');

        $preference->back_urls = array(
            "success" => base_url() . "Home/index?id=$id&monto=$monto&descripcion=$descripcion&correo=$correo",
            "failure" => base_url() . "Home/index?id=$id",
        );

        $preference->auto_return = "approved";
        $preference->binary_mode = true;
        $preference->save();
        echo json_encode(['id' => $preference->id]);
    }

    // BUSCAR PAGO EN MERCADO PAGO
    public static function consultarPago()
    {
        try {
            $client = new Payment();
            $id = '68920440413';
            $payment = $client->find_by_id($id);

            echo 'ID de Pago: ' . $payment->id . "\n";
            echo 'Estado de Pago: ' . $payment->status . "\n";
            echo 'Descripción: ' . $payment->description . "\n";
            echo 'Monto: ' . $payment->transaction_amount . "\n";
            echo 'Método de Pago: ' . $payment->payment_method_id . "\n";
            echo 'Fecha de Creación: ' . $payment->date_created . "\n";
            echo 'Detalles del Pagador: ' . print_r($payment->payer, true) . "\n";
        } catch (\Exception $e) {
            echo 'Caught exception: ',  $e->getMessage(), "\n";
        }
    }
}
